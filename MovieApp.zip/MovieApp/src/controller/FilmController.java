package controller;

import database.DBConnection;
import model.Film;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class FilmController {

    // ========================
    // CREATE - Tambah film baru
    // ========================
    public boolean tambahFilm(Film film) {
        String sql = "INSERT INTO film (judul, alur, penokohan, akting, nilai) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, film.getJudul());
            ps.setFloat(2, film.getAlur());
            ps.setFloat(3, film.getPenokohan());
            ps.setFloat(4, film.getAkting());
            ps.setFloat(5, film.getNilai());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("Error tambah film: " + e.getMessage());
            return false;
        }
    }

    // ========================
    // READ - Ambil semua film
    // ========================
    public List<Film> getAllFilm() {
        List<Film> listFilm = new ArrayList<>();
        String sql = "SELECT * FROM film";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Film f = new Film(
                    rs.getInt("id_film"),
                    rs.getString("judul"),
                    rs.getFloat("alur"),
                    rs.getFloat("penokohan"),
                    rs.getFloat("akting")
                );
                listFilm.add(f);
            }

        } catch (SQLException e) {
            System.err.println("Error ambil data: " + e.getMessage());
        }

        return listFilm;
    }

    // ========================
    // UPDATE - Ubah data film
    // ========================
    public boolean updateFilm(Film film) {
        String sql = "UPDATE film SET judul=?, alur=?, penokohan=?, akting=?, nilai=? WHERE id_film=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, film.getJudul());
            ps.setFloat(2, film.getAlur());
            ps.setFloat(3, film.getPenokohan());
            ps.setFloat(4, film.getAkting());
            ps.setFloat(5, film.getNilai());
            ps.setInt(6, film.getIdFilm());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("Error update film: " + e.getMessage());
            return false;
        }
    }

    // ========================
    // DELETE - Hapus film
    // ========================
    public boolean deleteFilm(int idFilm) {
        String sql = "DELETE FROM film WHERE id_film=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idFilm);
            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("Error hapus film: " + e.getMessage());
            return false;
        }
    }
}
