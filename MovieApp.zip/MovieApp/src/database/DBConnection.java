package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {

    // Sesuaikan dengan konfigurasi MySQL kamu
    private static final String URL      = "jdbc:mysql://localhost:3306/movie_db";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";  // Ganti jika ada password


    public static Connection getConnection() throws SQLException {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver tidak ditemukan! Pastikan file JAR sudah ada.");
        }
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
