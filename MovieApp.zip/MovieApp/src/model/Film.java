package model;

public class Film implements IFilm {

    // Private field = Encapsulation
    private int idFilm;
    private String judul;
    private float alur;
    private float penokohan;
    private float akting;

    // Constructor kosong
    public Film() {}

    // Constructor dengan parameter
    public Film(int idFilm, String judul, float alur, float penokohan, float akting) {
        this.idFilm    = idFilm;
        this.judul     = judul;
        this.alur      = alur;
        this.penokohan = penokohan;
        this.akting    = akting;
    }

    // Getter & Setter
    @Override public int    getIdFilm()    { return idFilm; }
    @Override public String getJudul()     { return judul; }
    @Override public float  getAlur()      { return alur; }
    @Override public float  getPenokohan() { return penokohan; }
    @Override public float  getAkting()    { return akting; }

    // Nilai rating dihitung otomatis
    @Override
    public float getNilai() {
        return (alur + penokohan + akting) / 3;
    }

    @Override public void setIdFilm(int idFilm)       { this.idFilm    = idFilm; }
    @Override public void setJudul(String judul)      { this.judul     = judul; }
    @Override public void setAlur(float alur)         { this.alur      = alur; }
    @Override public void setPenokohan(float pnk)     { this.penokohan = pnk; }
    @Override public void setAkting(float akting)     { this.akting    = akting; }
}
