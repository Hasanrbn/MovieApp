package model;

public interface IFilm {
    int getIdFilm();
    String getJudul();
    float getAlur();
    float getPenokohan();
    float getAkting();
    float getNilai();

    void setIdFilm(int idFilm);
    void setJudul(String judul);
    void setAlur(float alur);
    void setPenokohan(float penokohan);
    void setAkting(float akting);
}
