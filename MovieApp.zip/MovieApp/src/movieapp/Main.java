package movieapp;

import view.MainView;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Jalankan GUI di Event Dispatch Thread (standar Swing)
        SwingUtilities.invokeLater(() -> {
            MainView view = new MainView();
            view.setVisible(true);
        });
    }
}
