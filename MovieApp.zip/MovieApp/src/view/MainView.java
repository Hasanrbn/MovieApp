package view;

import controller.FilmController;
import model.Film;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * View: Tampilan GUI menggunakan Java Swing
 * Konsep MVC: View hanya menampilkan data dan menerima input dari user
 */
public class MainView extends JFrame {

    // Komponen tabel
    private JTable tabel;
    private DefaultTableModel modelTabel;

    // Komponen input
    private JTextField txtJudul, txtAlur, txtPenokohan, txtAkting;

    // Tombol
    private JButton btnTambah, btnUpdate, btnDelete, btnClear;

    // Controller
    private FilmController controller;

    // Menyimpan id film yang sedang dipilih
    private int idFilmDipilih = -1;

    public MainView() {
        controller = new FilmController();
        initKomponen();
        muatDataTabel();
    }

    /**
     * Inisialisasi semua komponen UI
     */
    private void initKomponen() {
        setTitle("Manajemen Data Movie");
        setSize(750, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ── Panel Kiri: Tabel ──────────────────────────────
        String[] kolomHeader = {"ID", "Judul", "Alur", "Penokohan", "Akting", "Nilai"};
        modelTabel = new DefaultTableModel(kolomHeader, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false; // tabel tidak bisa diedit langsung
            }
        };
        tabel = new JTable(modelTabel);
        tabel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabel.getColumnModel().getColumn(0).setMaxWidth(40); // kolom ID kecil

        JScrollPane scrollPane = new JScrollPane(tabel);
        add(scrollPane, BorderLayout.CENTER);

        // ── Panel Kanan: Form Input ────────────────────────
        JPanel panelForm = new JPanel();
        panelForm.setLayout(new GridBagLayout());
        panelForm.setPreferredSize(new Dimension(200, 0));
        panelForm.setBorder(BorderFactory.createTitledBorder("Form Input"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;

        // Label & TextField Judul
        gbc.gridx = 0; gbc.gridy = 0;
        panelForm.add(new JLabel("Judul:"), gbc);
        txtJudul = new JTextField();
        gbc.gridy = 1;
        panelForm.add(txtJudul, gbc);

        // Label & TextField Alur
        gbc.gridy = 2;
        panelForm.add(new JLabel("Alur (0-5):"), gbc);
        txtAlur = new JTextField();
        gbc.gridy = 3;
        panelForm.add(txtAlur, gbc);

        // Label & TextField Penokohan
        gbc.gridy = 4;
        panelForm.add(new JLabel("Penokohan (0-5):"), gbc);
        txtPenokohan = new JTextField();
        gbc.gridy = 5;
        panelForm.add(txtPenokohan, gbc);

        // Label & TextField Akting
        gbc.gridy = 6;
        panelForm.add(new JLabel("Akting (0-5):"), gbc);
        txtAkting = new JTextField();
        gbc.gridy = 7;
        panelForm.add(txtAkting, gbc);

        // Tombol Tambah
        btnTambah = new JButton("Tambah");
        gbc.gridy = 8;
        panelForm.add(btnTambah, gbc);

        // Tombol Update
        btnUpdate = new JButton("Update");
        gbc.gridy = 9;
        panelForm.add(btnUpdate, gbc);

        // Tombol Delete
        btnDelete = new JButton("Delete");
        gbc.gridy = 10;
        panelForm.add(btnDelete, gbc);

        // Tombol Clear
        btnClear = new JButton("Clear");
        gbc.gridy = 11;
        panelForm.add(btnClear, gbc);

        add(panelForm, BorderLayout.EAST);

        // ── Event Listener ─────────────────────────────────

        // Klik baris di tabel → isi form
        tabel.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                isiFormDariTabel();
            }
        });

        // Tombol Tambah
        btnTambah.addActionListener(e -> aksiTambah());

        // Tombol Update
        btnUpdate.addActionListener(e -> aksiUpdate());

        // Tombol Delete
        btnDelete.addActionListener(e -> aksiDelete());

        // Tombol Clear
        btnClear.addActionListener(e -> bersihkanForm());
    }

    /**
     * Muat semua data dari database ke tabel
     */
    private void muatDataTabel() {
        modelTabel.setRowCount(0); // kosongkan dulu
        List<Film> listFilm = controller.getAllFilm();
        for (Film f : listFilm) {
            modelTabel.addRow(new Object[]{
                f.getIdFilm(),
                f.getJudul(),
                f.getAlur(),
                f.getPenokohan(),
                f.getAkting(),
                String.format("%.2f", f.getNilai())
            });
        }
    }

    /**
     * Isi form dari baris yang dipilih di tabel
     */
    private void isiFormDariTabel() {
        int barisDipilih = tabel.getSelectedRow();
        if (barisDipilih >= 0) {
            idFilmDipilih  = (int) modelTabel.getValueAt(barisDipilih, 0);
            txtJudul.setText(modelTabel.getValueAt(barisDipilih, 1).toString());
            txtAlur.setText(modelTabel.getValueAt(barisDipilih, 2).toString());
            txtPenokohan.setText(modelTabel.getValueAt(barisDipilih, 3).toString());
            txtAkting.setText(modelTabel.getValueAt(barisDipilih, 4).toString());
        }
    }

    /**
     * Aksi tombol Tambah
     */
    private void aksiTambah() {
        try {
            Film film = ambilDataDariForm();
            boolean berhasil = controller.tambahFilm(film);

            if (berhasil) {
                JOptionPane.showMessageDialog(this, "Data Movie Berhasil Ditambahkan");
                muatDataTabel();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menambahkan data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Nilai alur, penokohan, akting harus berupa angka (0-5)!", "Error Input", JOptionPane.WARNING_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Aksi tombol Update
     */
    private void aksiUpdate() {
        if (idFilmDipilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin diupdate terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Film film = ambilDataDariForm();
            film.setIdFilm(idFilmDipilih);
            boolean berhasil = controller.updateFilm(film);

            if (berhasil) {
                JOptionPane.showMessageDialog(this, "Data Movie Berhasil Diupdate");
                muatDataTabel();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal mengupdate data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Nilai alur, penokohan, akting harus berupa angka (0-5)!", "Error Input", JOptionPane.WARNING_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error Validasi", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Aksi tombol Delete
     */
    private void aksiDelete() {
        if (idFilmDipilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin dihapus terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int konfirmasi = JOptionPane.showConfirmDialog(
            this,
            "Yakin ingin menghapus film: " + txtJudul.getText() + "?",
            "Konfirmasi Hapus",
            JOptionPane.YES_NO_OPTION
        );

        if (konfirmasi == JOptionPane.YES_OPTION) {
            boolean berhasil = controller.deleteFilm(idFilmDipilih);
            if (berhasil) {
                JOptionPane.showMessageDialog(this, "Data Movie Berhasil Dihapus");
                muatDataTabel();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Ambil data dari form dan kembalikan sebagai objek Film
     * Validasi dilakukan di sini
     */
    private Film ambilDataDariForm() {
        String judul = txtJudul.getText().trim();
        if (judul.isEmpty()) {
            throw new IllegalArgumentException("Judul tidak boleh kosong!");
        }

        float alur      = Float.parseFloat(txtAlur.getText().trim());
        float penokohan = Float.parseFloat(txtPenokohan.getText().trim());
        float akting    = Float.parseFloat(txtAkting.getText().trim());

        // Validasi rentang nilai 0-5
        if (alur < 0 || alur > 5 || penokohan < 0 || penokohan > 5 || akting < 0 || akting > 5) {
            throw new IllegalArgumentException("Nilai harus antara 0 sampai 5!");
        }

        return new Film(0, judul, alur, penokohan, akting);
    }

    /**
     * Bersihkan form input dan reset pilihan
     */
    private void bersihkanForm() {
        txtJudul.setText("");
        txtAlur.setText("");
        txtPenokohan.setText("");
        txtAkting.setText("");
        idFilmDipilih = -1;
        tabel.clearSelection();
    }
}
